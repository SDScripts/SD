ESX = exports["es_extended"]:getSharedObject()

local jobs = {}

local showJobs = false

-- STATION

for k, v in ipairs(Config.Station) do
    -- SPAWNER BLIP --
    local blip = AddBlipForCoord(v.pedcoords)

    SetBlipSprite(blip, 402)
    SetBlipColour(blip, 25)
    SetBlipScale(blip, 0.8)
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("TECHNIK")
    EndTextCommandSetBlipName(blip)

    -- SPAWNER BLIP END --

    -- SPAWNER --

    local sphere = lib.zones.sphere({
        coords = v.zone,
        radius = 1.5,
        debug = false,
        inside = function()
            if IsControlJustPressed(38, 38) and not showJobs and ESX.Game.IsSpawnPointClear(v.spawnPoint, 6.0) then
                ESX.Game.SpawnVehicle(v.carModel, v.spawnPoint, v.heading)
                showJobs = true
                works()
                local alert = lib.alertDialog({
                    header = 'Vitejte v nasi firme!',
                    content = 'Na mape jsme Vam oznacili pozice, kde je potreba opravit generatory!',
                    centered = true,
                    cancel = false,
                })
            -- else
            --     lib.notify({
            --         title = 'Technician Job',
            --         description = 'Something is blocking the spawnpoint!',
            --         type = 'error',
            --         position = 'center-right'
            --     })
            end
        end,
        onEnter = function()
            if not showJobs then
                lib.showTextUI('[E] - Car ')
            end
        end,
        onExit = function()
            lib.hideTextUI()
        end,
    })
    local sphere = lib.zones.sphere({
        coords = v.deletePoint,
        radius = 3,
        debug = false,
        inside = function()
            if cache.vehicle then
                if IsControlJustPressed(38, 38) and showJobs then
                    local vehicle = GetVehiclePedIsIn(cache.ped, false)
                    ESX.Game.DeleteVehicle(vehicle)
                    showJobs = false
                    for k, v in ipairs(jobs) do
                        RemoveBlip(v)
                    end
                end
            else
                lib.hideTextUI()
            end
        end,
        onEnter = function()
            if showJobs then
                lib.showTextUI('[E] - ZAPARKOVAT ')
            end
        end,
        onExit = function()
            lib.hideTextUI()
        end,
    })

    -- DELETER END --

    -- PED --

    lib.RequestModel(v.model)
    ped = CreatePed(1, v.model, v.pedcoords, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    -- PED END --
end

-- STATION END

function works()
    if showJobs then
        for k, v in ipairs(Config.Points) do
            local box = lib.zones.box({
                coords = v.coords,
                size = v.size,
                rotation = v.rotation,
                debug = false,
                inside = function()
                    lib.showTextUI('[G] - OPRAVIT')
                    if IsControlJustPressed(47, 47) and showJobs then
                        TriggerEvent("myAnimation")
                        local success = lib.skillCheck(Config.skillDifficulty, { 'w', 'a', 's', 'd' })
                        if success then
                            lib.callback('jocy-technician:reward')
                            lib.notify({
                                title = 'Technician',
                                description = 'Uspesne jste odstranil problem!',
                                type = 'success',
                                position = 'center-right'
                            })
                            ClearPedTasks(cache.ped)
                            lib.notify({
                                title = 'Jste unaveny, odpocinte si!',
                                type = 'warning',
                                position = 'top'
                            })
                            Citizen.Wait(Config.Cooldown)
                            lib.notify({
                                title = 'Technician',
                                description = 'Citite se lepe, muzete pokracovat!',
                                type = 'success',
                                position = 'center-right'
                            })
                        else
                            lib.notify({
                                title = 'Technician',
                                description = 'Pokazil jste praci!',
                                type = 'error',
                                position = 'center-right'
                            })
                            lib.notify({
                                title = 'Jste unaveny, odpocinte si!',
                                type = 'warning',
                                position = 'top'
                            })
                            ClearPedTasks(cache.ped)
                            Citizen.Wait(Config.Cooldown)
                        end
                    end
                end,
                onEnter = function()
                    lib.showTextUI('[G] - OPRAVIT')
                end,
                onExit = function()
                    lib.hideTextUI()
                end
            })

            -- blip
            local blip = AddBlipForCoord(v.coords)

            SetBlipSprite(blip, 354)
            SetBlipColour(blip, 60)
            SetBlipScale(blip, 0.8)
            SetBlipAsShortRange(blip, true)

            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("VYZADUJE OPRAVU")
            EndTextCommandSetBlipName(blip)

            table.insert(jobs, blip)
        end
    end
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(playerData)
    works()

end)

AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    works()
end)
